lib package
===========

Module contents
---------------

.. automodule:: lib
   :members:
   :undoc-members:
   :show-inheritance:
