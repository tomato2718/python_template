'''
Not for import, import Style instead.
'''

from ._style import Style