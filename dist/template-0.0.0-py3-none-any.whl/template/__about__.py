'''
Informations about the project.
'''

__all__ = ['__project__',
           '__version__',
           '__author__',
           '__maintainer__',
           '__release__',
           '__summary__',
           '__usage__'
           ]

__project__ = 'template'
__version__ = '0.0.0'
__author__ = 'yveschen2718@gmail.com'
__maintainer__ = 'yveschen2718@gmail.com'
__release__ = '2023/05/05'
__summary__ = 'Python project template'
__usage__ = f'''
Usage:
    >>> 
    >>> 
    >>> 
'''